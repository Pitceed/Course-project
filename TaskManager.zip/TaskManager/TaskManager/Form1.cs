﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics;
using System.Management;
using Microsoft.VisualBasic;

namespace TaskManager
{
    public partial class Form1 : Form
    {
        private List<Process> processes = null;
        private List<ProcessThread> pthreads = null;
        private ListViewItemComparer comparer = null;
        private bool treadFlag = false;
        public Form1()
        {
            InitializeComponent();
        }
        private void GetProcesses()
        {
            processes.Clear();
            processes = Process.GetProcesses().ToList<Process>();
        }
        private void GetThreads()
        {
            GetProcesses();
            pthreads.Clear();
            foreach (Process p in processes)
            {
                foreach (ProcessThread t in p.Threads)
                {
                    pthreads.Add(t);
                }
            }
        }
        private void RefreshThreadsList()
        {
            listView1.Items.Clear();
            try
            {
            foreach (ProcessThread t in pthreads)
            {
                    try
                    {
                        if (t != null)
                        {
                        string[] row = new string[] { t.Id.ToString(), t.ThreadState.ToString(), t.PriorityLevel.ToString() };
                        listView1.Items.Add(new ListViewItem(row));
                        }
                    }
                    catch (Exception) { }
                }
            Text = "Запущено потоків: " + pthreads.Count.ToString();
            }
            catch (Exception) { }
        }
        private void RefreshThreadsList(List<ProcessThread> pthreads, string keyword)
        {
            try
            {
                listView1.Items.Clear();
                foreach (ProcessThread t in pthreads)
                {
                    try
                    {
                        if (t != null)
                    {
                        string[] row = new string[] { t.Id.ToString(), t.ThreadState.ToString(), t.PriorityLevel.ToString() };
                        listView1.Items.Add(new ListViewItem(row));
                    }
                    }
                    catch (Exception) { }
                }
                Text = $"Запущено потоків: '{keyword}'" + pthreads.Count.ToString();
            }
            catch (Exception) { }
        }
        private void RefreshProcessesList()
        {
            listView1.Items.Clear();
            double memSize = 0;
            foreach(Process p in processes)
            {
                memSize = 0;
                PerformanceCounter pc = new PerformanceCounter();
                pc.CategoryName = "Process";
                pc.CounterName = "Working Set - Private";
                pc.InstanceName = p.ProcessName;
                memSize = (double)pc.NextValue() / (1000 * 1000);
                string[] row = new string[] { p.Id.ToString(), p.ProcessName.ToString(), Math.Round(memSize, 1).ToString(), p.Threads.Count.ToString() };
                listView1.Items.Add(new ListViewItem(row));
                pc.Close();
                pc.Dispose();
            }
            Text = "Запущено процесів: " + processes.Count.ToString();
        }
        private void RefreshProcessesList(List<Process> processes, string keyword)
        {
            try
            {
                listView1.Items.Clear();
                double memSize = 0;
                foreach (Process p in processes)
                {
                    if (p != null)
                    {
                        memSize = 0;
                        PerformanceCounter pc = new PerformanceCounter();
                        pc.CategoryName = "Process";
                        pc.CounterName = "Working Set - Private";
                        pc.InstanceName = p.ProcessName;
                        memSize = (double)pc.NextValue() / (1000 * 1000);
                        string[] row = new string[] { p.Id.ToString(), p.ProcessName.ToString(), Math.Round(memSize, 1).ToString(), p.Threads.Count.ToString() };
                        listView1.Items.Add(new ListViewItem(row));
                        pc.Close();
                        pc.Dispose();
                    }
                }
                Text = $"Запущено процесів: '{keyword}'" + processes.Count.ToString();
            }
            catch (Exception) { }
        }
        private void KillProcess(Process process)
        {
            process.Kill();
            process.WaitForExit();
        }
        private void KillThread(ProcessThread thread)
        {
            thread.Dispose();
        }
        private void KillProcessAndChildren(int pid)
        {
            if(pid == 0)
            {
                return;
            }
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                "Select * From Win32_Process Where ParentProcessID="+pid
                );
            ManagementObjectCollection objectCollection = searcher.Get();

            foreach(ManagementObject obj in objectCollection)
            {
                KillProcessAndChildren(Convert.ToInt32(obj["ProcessID"]));
            }

            try
            {
                Process p = Process.GetProcessById(pid);
                p.Kill();
                p.WaitForExit();
            }
            catch(ArgumentException){ }
        }
        private int GetParentProcessId(Process p)
        {
            int ParentID = 0;

            try
            {
                ManagementObject managementObject = new ManagementObject("win32_process.handle='" + p.Id + "'");
                managementObject.Get();
                ParentID = Convert.ToInt32(managementObject["ParentProcessId"]);
            }
            catch (Exception) { }
            return ParentID;
        }
        private void TreadFlagChanged()
        {
            comparer.processOrThread = treadFlag;
            запуститиПроцесToolStripMenuItem.Visible = !treadFlag;
            завершитиДревоToolStripMenuItem.Visible = !treadFlag;
            завершитиПотокToolStripMenuItem.Visible = treadFlag;
            завершитиToolStripMenuItem1.Visible = !treadFlag;
            завершитиПотокToolStripMenuItem1.Visible = treadFlag;
            завершитиДеревоToolStripMenuItem.Visible = !treadFlag;
            завершитиToolStripMenuItem.Visible = !treadFlag;
            toolStripButton2.Text = !treadFlag ? "Потоки" : "Процеси";
            toolStripLabel1.Text = !treadFlag ? "Пошук за ім'ям" : "Пошук за id";
            listView1.Columns.Remove(name);
            listView1.Columns.Remove(memory);
            listView1.Columns.Remove(threads);
            listView1.Columns.Remove(priority);
            listView1.Columns.Remove(state);
            if (treadFlag)
            {
                listView1.Columns.Remove(memory);
                listView1.Columns.Remove(threads);
                listView1.Columns.Remove(name);
                listView1.Columns.Add(state);
                listView1.Columns.Add(priority);
            }
            else
            {
                listView1.Columns.Add(name);
                listView1.Columns.Add(memory);
                listView1.Columns.Add(threads);
                listView1.Columns.Remove(priority);
                listView1.Columns.Remove(state);
            }
            contextMenuStrip1.Invalidate();
            toolStrip1.Invalidate();
            listView1.Invalidate();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            processes = new List<Process>();
            pthreads = new List<ProcessThread>();
            comparer = new ListViewItemComparer();
            comparer.ColumnIndex = 0;
            comparer.processOrThread = treadFlag;
            TreadFlagChanged();
        }
        private void завершитиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                if (listView1.SelectedItems[0]!=null)
                {
                    Process processToKill = processes.Where((x) => x.Id.ToString() ==
                    listView1.SelectedItems[0].SubItems[0].Text).ToList()[0];

                    KillProcess(processToKill);

                    GetProcesses();
                    RefreshProcessesList();
                }
            }
            catch (Exception) { }
        }
        private void завершитиДревоToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (listView1.SelectedItems[0] != null)
                {
                    Process processToKill = processes.Where((x) => x.Id.ToString() ==
                    listView1.SelectedItems[0].SubItems[0].Text).ToList()[0];

                    KillProcessAndChildren(GetParentProcessId(processToKill));

                    GetProcesses();
                    RefreshProcessesList();
                }
            }
            catch (Exception) { }
        }
        private void завершитиДеревоToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (listView1.SelectedItems[0] != null)
                {
                    Process processToKill = processes.Where((x) => x.Id.ToString() ==
                    listView1.SelectedItems[0].SubItems[0].Text).ToList()[0];

                    KillProcessAndChildren(GetParentProcessId(processToKill));

                    GetProcesses();
                    RefreshProcessesList();
                }
            }
            catch (Exception) { }
        }
        private void запуститиПроцесToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string path = Interaction.InputBox("Введіть ім'я нової програми", "Запуск нового процесу");
            try
            {
                Process.Start(path);
            }
            catch (Exception) { }
        }
        private void завершитиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (listView1.SelectedItems[0] != null)
                {
                    Process processToKill = processes.Where((x) => x.Id.ToString() ==
                    listView1.SelectedItems[0].SubItems[0].Text).ToList()[0];

                    KillProcess(processToKill);

                    GetProcesses();
                    RefreshProcessesList();
                }
            }
            catch (Exception) { }
        }
        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            comparer.ColumnIndex = e.Column;
            comparer.SortDirection = comparer.SortDirection == SortOrder.Ascending ? SortOrder.Descending : SortOrder.Ascending;
            listView1.ListViewItemSorter = comparer;
            listView1.Sort();
        }
        private void вихідToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void Form1_Shown(object sender, EventArgs e)
        {
            if (treadFlag)
            {
                GetThreads();
                RefreshThreadsList();
            }
            else
            {
                GetProcesses();
                RefreshProcessesList();
            }
        }
        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            if (treadFlag)
            {
                
                GetThreads();
                List<ProcessThread> filteredthread = pthreads.Where((x) =>
                x.Id.ToString().Contains(toolStripTextBox1.Text)).ToList<ProcessThread>();
                RefreshThreadsList(filteredthread, toolStripTextBox1.Text);
            }
            else
            {
                GetProcesses();
                List<Process> filteredprocesses = processes.Where((x) =>
                x.ProcessName.ToLower().Contains(toolStripTextBox1.Text.ToLower())).ToList<Process>();
                RefreshProcessesList(filteredprocesses, toolStripTextBox1.Text);
            }
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (treadFlag)
            {
                GetThreads();
                RefreshThreadsList();
            }
            else
            {
                GetProcesses();
                RefreshProcessesList();
            }
        }
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Програму розробив студент КІУКІ-20-7 Прошкін А.С. ", "Курсовий проект ", MessageBoxButtons.OK, MessageBoxIcon.Information,MessageBoxDefaultButton.Button1);
        }
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            treadFlag = !treadFlag;
            TreadFlagChanged();
            if (treadFlag)
            {
                GetThreads();
                RefreshThreadsList();
            }
            else
            {
                GetProcesses();
                RefreshProcessesList();
            }
        }
        private void завершитиПотокToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (listView1.SelectedItems[0] != null)
                {
                    ProcessThread threadToKill = pthreads.Where((x) => x.Id.ToString() ==
                    listView1.SelectedItems[0].SubItems[0].Text).ToList()[0];

                    KillThread(threadToKill);

                    GetThreads();
                    RefreshThreadsList();
                }
            }
            catch (Exception) { }
        }
        private void завершитиПотокToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                if (listView1.SelectedItems[0] != null)
                {
                    ProcessThread threadToKill = pthreads.Where((x) => x.Id.ToString() ==
                    listView1.SelectedItems[0].SubItems[0].Text).ToList()[0];

                    KillThread(threadToKill);

                    GetThreads();
                    RefreshThreadsList();
                }
            }
            catch (Exception) { }
        }
    }
}
