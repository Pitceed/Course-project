﻿using System.Collections;
using System.Windows.Forms;

namespace TaskManager
{
    internal class ListViewItemComparer : IComparer
    {
        private int _columnIndex;
        private bool _processOrThread;
        public int ColumnIndex
        {
            get { return _columnIndex; }
            set { _columnIndex = value; }
        }
        public bool processOrThread
        {
            get { return _processOrThread; }
            set { _processOrThread = value; }
        }
        private SortOrder _sortDirection;
        public SortOrder SortDirection
        {
            get { return _sortDirection; }
            set { _sortDirection = value; }
        }       
        public ListViewItemComparer()
        {
            _sortDirection = SortOrder.None;
        }
        public int Compare(object x, object y)
        {
            ListViewItem listViewItemX = x as ListViewItem;
            ListViewItem listViewItemY = y as ListViewItem;
            int result;
            if (!processOrThread)
            {
                switch (_columnIndex)
                {
                    case 1:
                        result = string.Compare(listViewItemX.SubItems[_columnIndex].Text,
                            listViewItemY.SubItems[_columnIndex].Text, false);
                        break;
                    case 0:
                    case 2:
                    case 3:
                        double valueX = double.Parse(listViewItemX.SubItems[_columnIndex].Text);
                        double valueY = double.Parse(listViewItemY.SubItems[_columnIndex].Text);
                        result = valueX.CompareTo(valueY);
                        break;
                    default:
                        result = string.Compare(listViewItemX.SubItems[_columnIndex].Text,
                            listViewItemY.SubItems[_columnIndex].Text, false);
                        break;
                }
                if (_sortDirection == System.Windows.Forms.SortOrder.Descending)
                {
                    return -result;
                }
                else
                {
                    return result;
                }
            }
            else
            {
                switch (_columnIndex)
                {
                    case 1:
                    case 2:
                        result = string.Compare(listViewItemX.SubItems[_columnIndex].Text,
                            listViewItemY.SubItems[_columnIndex].Text, false);
                        break;
                    case 0:
                        double valueX = double.Parse(listViewItemX.SubItems[_columnIndex].Text);
                        double valueY = double.Parse(listViewItemY.SubItems[_columnIndex].Text);
                        result = valueX.CompareTo(valueY);
                        break;
                    default:
                        result = string.Compare(listViewItemX.SubItems[_columnIndex].Text,
                            listViewItemY.SubItems[_columnIndex].Text, false);
                        break;
                }
                if (_sortDirection == System.Windows.Forms.SortOrder.Descending)
                {
                    return -result;
                }
                else
                {
                    return result;
                }
            }
        }
    }

}
