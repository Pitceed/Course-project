﻿namespace TaskManager
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.завершитиToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.завершитиДревоToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.завершитиПотокToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запуститиПроцесToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.вихідToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.listView1 = new System.Windows.Forms.ListView();
            this.id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.memory = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.threads = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.state = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.priority = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.завершитиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.завершитиДеревоToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.завершитиПотокToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.toolStripTextBox1,
            this.toolStripSeparator1,
            this.toolStripDropDownButton1,
            this.toolStripButton1,
            this.toolStripSeparator2,
            this.toolStripButton4,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(631, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripLabel1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripLabel1.Image")));
            this.toolStripLabel1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(97, 22);
            this.toolStripLabel1.Text = "Пошук за ім\'ям";
            this.toolStripLabel1.Click += new System.EventHandler(this.toolStripLabel1_Click);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 25);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.завершитиToolStripMenuItem1,
            this.завершитиДревоToolStripMenuItem,
            this.завершитиПотокToolStripMenuItem,
            this.запуститиПроцесToolStripMenuItem,
            this.toolStripMenuItem2,
            this.вихідToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(49, 22);
            this.toolStripDropDownButton1.Text = "Файл";
            // 
            // завершитиToolStripMenuItem1
            // 
            this.завершитиToolStripMenuItem1.Name = "завершитиToolStripMenuItem1";
            this.завершитиToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.завершитиToolStripMenuItem1.Text = "Завершити процес";
            this.завершитиToolStripMenuItem1.Click += new System.EventHandler(this.завершитиToolStripMenuItem1_Click);
            // 
            // завершитиДревоToolStripMenuItem
            // 
            this.завершитиДревоToolStripMenuItem.Name = "завершитиДревоToolStripMenuItem";
            this.завершитиДревоToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.завершитиДревоToolStripMenuItem.Text = "Завершити древо";
            this.завершитиДревоToolStripMenuItem.Click += new System.EventHandler(this.завершитиДревоToolStripMenuItem_Click);
            // 
            // завершитиПотокToolStripMenuItem
            // 
            this.завершитиПотокToolStripMenuItem.Name = "завершитиПотокToolStripMenuItem";
            this.завершитиПотокToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.завершитиПотокToolStripMenuItem.Text = "Завершити поток";
            this.завершитиПотокToolStripMenuItem.Visible = false;
            this.завершитиПотокToolStripMenuItem.Click += new System.EventHandler(this.завершитиПотокToolStripMenuItem_Click);
            // 
            // запуститиПроцесToolStripMenuItem
            // 
            this.запуститиПроцесToolStripMenuItem.Name = "запуститиПроцесToolStripMenuItem";
            this.запуститиПроцесToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.запуститиПроцесToolStripMenuItem.Text = "Запустити процес";
            this.запуститиПроцесToolStripMenuItem.Click += new System.EventHandler(this.запуститиПроцесToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(177, 6);
            // 
            // вихідToolStripMenuItem
            // 
            this.вихідToolStripMenuItem.Name = "вихідToolStripMenuItem";
            this.вихідToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.вихідToolStripMenuItem.Text = "Вихід";
            this.вихідToolStripMenuItem.Click += new System.EventHandler(this.вихідToolStripMenuItem_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(59, 22);
            this.toolStripButton1.Text = "Оновити";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(91, 22);
            this.toolStripButton4.Text = "Про програму";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(52, 22);
            this.toolStripButton2.Text = "Потоки";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.id,
            this.name,
            this.memory,
            this.threads,
            this.state,
            this.priority});
            this.listView1.ContextMenuStrip = this.contextMenuStrip1;
            this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(0, 25);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(631, 325);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView1_ColumnClick);
            // 
            // id
            // 
            this.id.Text = "Ідентифікатор";
            this.id.Width = 85;
            // 
            // name
            // 
            this.name.Text = "Ім\'я";
            this.name.Width = 200;
            // 
            // memory
            // 
            this.memory.Text = "Пам\'ять";
            this.memory.Width = 90;
            // 
            // threads
            // 
            this.threads.Text = "Потоків";
            this.threads.Width = 90;
            // 
            // state
            // 
            this.state.Text = "Стан";
            // 
            // priority
            // 
            this.priority.Text = "Пріорітет";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.завершитиToolStripMenuItem,
            this.завершитиДеревоToolStripMenuItem,
            this.завершитиПотокToolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(180, 70);
            // 
            // завершитиToolStripMenuItem
            // 
            this.завершитиToolStripMenuItem.Name = "завершитиToolStripMenuItem";
            this.завершитиToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.завершитиToolStripMenuItem.Text = "Завершити процес";
            this.завершитиToolStripMenuItem.Click += new System.EventHandler(this.завершитиToolStripMenuItem_Click);
            // 
            // завершитиДеревоToolStripMenuItem
            // 
            this.завершитиДеревоToolStripMenuItem.Name = "завершитиДеревоToolStripMenuItem";
            this.завершитиДеревоToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.завершитиДеревоToolStripMenuItem.Text = "Завершити древо";
            this.завершитиДеревоToolStripMenuItem.Click += new System.EventHandler(this.завершитиДеревоToolStripMenuItem_Click);
            // 
            // завершитиПотокToolStripMenuItem1
            // 
            this.завершитиПотокToolStripMenuItem1.Name = "завершитиПотокToolStripMenuItem1";
            this.завершитиПотокToolStripMenuItem1.Size = new System.Drawing.Size(179, 22);
            this.завершитиПотокToolStripMenuItem1.Text = "Завершити поток";
            this.завершитиПотокToolStripMenuItem1.Visible = false;
            this.завершитиПотокToolStripMenuItem1.Click += new System.EventHandler(this.завершитиПотокToolStripMenuItem1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(631, 350);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "Form1";
            this.Text = "TaskManager";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader name;
        private System.Windows.Forms.ColumnHeader memory;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem завершитиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem завершитиДеревоToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem завершитиToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem завершитиДревоToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem запуститиПроцесToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem вихідToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripLabel1;
        private System.Windows.Forms.ColumnHeader id;
        private System.Windows.Forms.ColumnHeader threads;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripMenuItem завершитиПотокToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem завершитиПотокToolStripMenuItem1;
        private System.Windows.Forms.ColumnHeader state;
        private System.Windows.Forms.ColumnHeader priority;
    }
}

